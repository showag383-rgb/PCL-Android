# PCL2 → Android (FCL) 移植路线图

> 本文是源码级功能映射和实施顺序，不代表这些页面已经移植完成。PCL2 原项目为 VB.NET/WPF；Android 端以 FCL 的原生 Android 页面和 Minecraft Java 运行引擎为基础实现。

## 已确认的基础

- PCL2 源码位置：`Plain Craft Launcher 2/`，核心页面位于 `Pages/`，Minecraft 功能位于 `Modules/Minecraft/`。
- FCL Android 工程模块：`FCL`；主界面和游戏引擎已有 Android 实现。
- Android 最低版本配置为 API 26（Android 8），因此覆盖 Android 10+。
- 目标构建架构：`arm64-v8a`（Gradle 参数 `-Darch=arm64`）。

## 功能映射

| PCL2 页面/模块 | PCL2 源码位置 | Android 侧可复用的 FCL 入口 | 移植策略 |
|---|---|---|---|
| 启动主页 | `Pages/PageLaunch/` | `ui/main/MainUI.java`、`activity/MainActivity.kt` | 优先重做主页布局和快捷入口；不重写启动引擎 |
| 账户登录/角色 | `Pages/PageLaunch/PageLogin*.xaml.vb` | `ui/account/AccountUI.java`、`ui/account/*Login*` | 保留 FCL OAuth/离线账户实现，统一 PCL 风格入口与文案 |
| 版本列表/实例 | `Pages/PageInstance/` | `ui/version/VersionUI.java`、`ui/version/VersionListPage.kt` | 以 FCL 版本数据为准，重做列表卡片、选中态和实例详情导航 |
| 版本安装/下载 | `Pages/PageDownload/` | `ui/download/DownloadUI.java`、`ui/download/version/` | 保留 FCL 下载任务与依赖解析，调整分类和安装流程视觉层 |
| 模组/资源管理 | `Pages/PageInstance/PageInstanceMod*`、`Pages/PageDownload/Resource/` | `ui/manage/ModListPage.java`、`ui/download/common/` | 复用 FCL 模组管理和 Modrinth/CurseForge 等现有适配 |
| 启动参数/Java 设置 | `Modules/Minecraft/ModLaunch.vb`、`ModJava.vb`、`Pages/PageSetup/` | `game/FCLGameLauncher.java`、`ui/setting/`、`ui/version/VersionSettingPage.kt` | 仅迁移可映射的设置项；Android 专属内存、渲染和输入选项继续采用 FCL 实现 |
| 游戏启动/崩溃日志 | `Modules/Minecraft/ModLaunch.vb`、`ModCrash.vb` | `game/FCLGameLauncher.java`、`game/LogExporter.java` | 必须使用 FCL Android 启动链路，不能调用 Windows PCL2 的进程/路径代码 |

## 分阶段实施顺序

1. **品牌与主页**：PCL Community 独立包名、应用名称、主页结构与导航。
2. **核心操作闭环**：账户选择 → 版本列表 → 安装版本 → Java 运行环境 → 启动游戏。
3. **实例管理**：版本设置、目录/资源管理、模组管理。
4. **设置与辅助**：启动参数、内存、分辨率、控制器、日志导出。
5. **视觉精修**：颜色、卡片、图标、间距、动效和窄屏适配。
6. **验证**：Android 10、较新 Android、arm64 真机；分别验证离线账户、微软账户、原版版本、Fabric/Forge（以 FCL 实际支持为准）。

## 当前完成度（诚实标记）

- [x] 确认 PCL2 为 Windows WPF 项目，不能直接转换成 APK。
- [x] 确认 FCL 有 Android Java 版运行链路及账户、版本、下载、模组和设置页面。
- [x] 增加 `pclDev` 独立 Android 构建变体和初步品牌标识。
- [x] 增加 ARM64 GitHub Actions 构建工作流。
- [ ] 完整重做 PCL2 风格主页及各子页面。
- [ ] Android Gradle 编译成功并产出 APK。
- [ ] Android 10+ 真机安装与登录/下载/启动测试。

## 重要技术边界

PCL2 的 WPF XAML、VB.NET 事件代码、Windows 文件路径、Windows Java 进程管理不能原样移入 Android。可迁移的是页面信息架构、交互逻辑、文案、设置语义和视觉设计；Android 实际执行必须落到 FCL 的 Kotlin/Java 与 Android API。
