#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
TARGET="${1:-.}"
cp -a "$ROOT/overlay/." "$TARGET/"
echo "PCL Community Launcher 0.6.0-dev overlay applied to: $TARGET"
