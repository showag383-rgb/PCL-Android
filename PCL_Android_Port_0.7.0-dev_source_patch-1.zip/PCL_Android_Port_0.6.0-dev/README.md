# PCL Community Launcher 0.6.0-dev — source overlay

This is a source overlay for the exact `FoldCraftLauncher-main` source tree supplied by the user. It is **not an APK**.

## Changes in this patch

- Adds the `pclDev` Android build type. It uses a separate `com.tungsten.fcl.pcl` application ID and the FCL debug signing configuration, so it can coexist with the regular FCL app and does not require the private release keystore.
- Gives the `pclDev` variant the app label `PCL Community Launcher`.
- Adds a small PCL Community identity header to the existing home content while retaining FCL's existing runtime, account, version, download, controller, mod and launch flows.
- Adds a manually triggered GitHub Actions workflow that builds an ARM64 APK on a hosted Android build runner and uploads it as an artifact.

## Apply

From the root of the extracted `FoldCraftLauncher-main` repository, copy the contents of `overlay/` into the repository root, preserving paths.

## Build locally

Requires JDK 21, Android SDK platform 35, Android NDK `27.0.12077973`, and network access for Gradle/Maven dependencies:

```bash
./gradlew :FCL:assemblePclDev -Darch=arm64 --no-daemon
```

Expected output directory:

```text
FCL/build/outputs/apk/pclDev/
```

## Build using GitHub Actions

Push the patched repository to a GitHub repository, open **Actions**, select **Build PCL Community Launcher (ARM64)**, and choose **Run workflow**. The resulting APK is uploaded as the workflow artifact.

## Validation status

- Source archive ZIP integrity: checked.
- `ui_main.xml`: parsed successfully as XML.
- `pclDev` build type and isolated package ID: checked in source.
- GitHub Actions workflow: parsed as YAML.
- Android/Gradle compilation: **not run in this environment** because Android SDK/NDK and the required Gradle distribution are not installed/cached, and the environment cannot fetch the Gradle distribution. No APK or runtime success is claimed.

## Important

This is an incremental FCL-based Android community launcher, not a direct port of PCL2's WPF/.NET code. It retains FCL's existing Minecraft Java runtime implementation. The PCL2 source archive supplied by the user is VB.NET/WPF and cannot be compiled as an Android app. This patch does not yet recreate all PCL2 screens or independently verify Minecraft login/download/game launch on a phone.

## PCL2 功能映射

请先阅读同目录的 [`PCL2_TO_FCL_PORT_MAP.md`](PCL2_TO_FCL_PORT_MAP.md)。该文档列出 PCL2 页面与 FCL Android 页面之间的源码对应关系、迁移策略和未完成事项，避免把当前品牌补丁误认为完整 PCL2 移植。
